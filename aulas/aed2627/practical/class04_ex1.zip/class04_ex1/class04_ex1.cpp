// AED 2026/2027 [Ana Paula Tomas and Pedro Ribeiro - DCC/FCUP]
// Testing sorting algorithms

#include <ctime>
#include <fstream>
#include <vector>
#include <iostream>
#include <iomanip>
#include <algorithm>

#define PRECISION 6 // precision shown on time prints

using namespace std;

/*
//------ Conditional compilation ---------

g++ -std=c++17 -D SELECTIONSORT -D SMALL class04_ex1.cpp
// selection sort and will test the small size examples (n = 1000)

g++ -std=c++17 -D INSERTIONSORT -D SMALL -D MEDIUM class04_ex1.cpp
// small and medium size

g++ -std=c++17 -D INSERTIONSORT -D SMALL class04_ex1.cpp
g++ -std=c++17 -D MERGESORT -D SMALL class04_ex1.cpp
g++ -std=c++17 -D QUICKSORT -D SMALL class04_ex1.cpp
g++ -std=c++17 -D RANDOMIZEDQUICKSORT -D SMALL  class04_ex1.cpp


g++ -std=c++17 -D SELECTIONSORT -D MEDIUM class04_ex1.cpp
g++ -std=c++17 -D INSERTIONSORT -D MEDIUM class04_ex1.cpp
g++ -std=c++17 -D MERGESORT -D MEDIUM class04_ex1.cpp
g++ -std=c++17 -D QUICKSORT -D MEDIUM class04_ex1.cpp
g++ -std=c++17 -D RANDOMIZEDQUICKSORT -D MEDIUM  class04_ex1.cpp

g++ -std=c++17 -D SELECTIONSORT -D LARGE class04_ex1.cpp
g++ -std=c++17 -D INSERTIONSORT -D LARGE class04_ex1.cpp
g++ -std=c++17 -D MERGESORT -D LARGE class04_ex1.cpp
g++ -std=c++17 -D QUICKSORT -D LARGE class04_ex1.cpp
g++ -std=c++17 -D RANDOMIZEDQUICKSORT -D LARGE class04_ex1.cpp

g++ -std=c++17 -D MERGESORT -D HUGE class04_ex1.cpp
g++ -std=c++17 -D RANDOMIZEDQUICKSORT -D HUGE class04_ex1.cpp

g++ -std=c++17 -D STL_SORT -D HUGE class04_ex1.cpp

*/


//=========  sort (STL C++) ========

#ifdef STL_SORT
template<class Comparable>
void sort(vector<Comparable> &v){
  sort(v.begin(),v.end());
}
#endif


//======  selection sort==============================
#ifdef SELECTIONSORT
template<class Comparable>
void sort(vector<Comparable> &v){
  for(unsigned k=0; k < v.size()-1; k++){
    unsigned pmin=k;
    for(unsigned j=k+1; j < v.size(); j++)
      if(v[j] < v[pmin])
        pmin = j;
    swap(v[k],v[pmin]);
  }
}
#endif

//======  insertion sort==============================
#ifdef INSERTIONSORT
template<class Comparable>
void sort(vector<Comparable> &v){
  for (unsigned k = 1; k < v. size (); k++) {
  Comparable tmp = v[k];
  unsigned j;
  for (j = k; j > 0 && tmp < v[j -1]; j --)
    v[j] = v[j -1];
  v[j] = tmp;
 }
}
#endif

//======  merge sort==============================
#ifdef MERGESORT
template <class Comparable>
void merge(vector<Comparable> &v, vector<Comparable> &tmp, 
                  int leftPos, int rightPos, int rightEnd) {
  int leftEnd = rightPos-1, tmpPos = leftPos;
  int numElements = rightEnd-leftPos+1;

  while (leftPos <= leftEnd && rightPos <= rightEnd) 
    if (v[leftPos] <= v[rightPos])  
       tmp[tmpPos++] = v[leftPos++];
    else tmp[tmpPos++] = v[rightPos++];
 
  while(leftPos <= leftEnd)      // if left has not ended 
     tmp[tmpPos++] = v[leftPos++];
  while(rightPos <= rightEnd)        //  if right has not ended
     tmp[tmpPos++] = v[rightPos++];
  for(int i=0; i < numElements; i++, rightEnd--) // copy to v
     v[rightEnd] = tmp[rightEnd];
}


// internal method , makes recursive calls
template <class Comparable>
void mergeSort(vector<Comparable> &v,vector<Comparable> &tmp,
                       int left , int right ) {
  if (left < right){ 
    int middle = left + (right-left)/2;
    mergeSort(v, tmp, left , middle);
    mergeSort(v, tmp, middle + 1, right);
    merge(v, tmp, left, middle + 1, right);
  }
}


template <class Comparable>
void sort(vector<Comparable> &v){
  vector<Comparable> tmpArr(v.size());
  mergeSort(v,tmpArr,0,v.size()-1);
}
#endif


//======  quicksort sort (deterministic version) ==============================

#ifdef QUICKSORT
template <class Comparable>
int partition(vector<Comparable> &v, int left, int right){
  int pivotPos = left;
  for (int j = left+1; j <= right; j++)
    if (v[j] <= v[left]) {
       pivotPos = pivotPos+1;
       swap(v[pivotPos],v[j]);
    }
  swap(v[left],v[pivotPos]);
  return pivotPos;
}  

template <class Comparable>
void quickSort(vector<Comparable> &v, int left, int right){
   if (left < right){ 
     int pivotPos = partition(v, left, right);
     quickSort(v, left, pivotPos - 1);
     quickSort(v, pivotPos + 1, right);
   }
}

template <class Comparable>
void sort(vector<Comparable> &v) {
  quickSort(v,0,v.size()-1);
}
#endif


//======  randomized quicksort ==============================

#ifdef RANDOMIZEDQUICKSORT
template <class Comparable>
int partition(vector<Comparable> &v, int left, int right){

  // ---- randomized version --------------
    int tmp = left + rand() % (right-left+1);          
     swap(v[tmp],v[left]);
  //-----------------------------

  int pivotPos = left;
  for (int j = left+1; j <= right; j++)
    if (v[j] <= v[left]) {
       pivotPos = pivotPos+1;
       swap(v[pivotPos],v[j]);
    }
  swap(v[left],v[pivotPos]);
  return pivotPos;
}  


template <class Comparable>
void quickSort(vector<Comparable> &v, int left, int right){
   if (left < right){ 
     int pivotPos = partition(v, left, right);
     quickSort(v, left, pivotPos - 1);
     quickSort(v, pivotPos + 1, right);
   }
}

template <class Comparable>
void sort(vector<Comparable> &v) {
  quickSort(v,0,v.size()-1);
}
#endif



//---------------------------------------------------------------
//   Testing with sequences of ints, or chars or strings
//---------------------------------------------------------------------


// ---------------------------------------------------------------------
// Auxiliary function: read sequence to a vector from an input stream
// First read an integer n (the amount of elements) and then n elements
// ---------------------------------------------------------------------

template <class T>
vector<T> readIntVector(ifstream & f) {
  int n;
  f >> n;
  vector<T> v(n);
  for (int i=0; i<n; i++) f >> v[i];
  return v;
}


// ---------------------------------------------------------------------
// Test a sort function reading input from 'inputFile' and the
// expected output from outputFile
// ---------------------------------------------------------------------
template <class T>
void testSort(const string & inputFile, const string & outputFile) {

  // Open input file and store vector and keys to search
  ifstream input(inputFile);
  if (!input) {
    cerr << inputFile << " not found!" << endl;
    exit(1);
  }
  vector<T> seq   = readIntVector<T>(input);
  input.close();

  // Open output file and store expected answers
  ifstream output(outputFile);
  if (!output) {
    cerr << outputFile << " not found!" << endl;
    exit(1);
  }
  vector<T> correct = readIntVector<T>(output);
  output.close();
    
  int n = seq.size();
  vector<T> answer(n);
  cout << ". Case with n = " << n;

  // Call 'sort' function 
  clock_t cstart = clock();
  sort<T>(seq);
  clock_t cend = clock();

  // Check if answer is the expected one
  int i;
  for (i=0; i<n; i++)
    if (seq[i] != correct[i]) {
      cout << " [INCORRECT]" << endl;
      break;
    }
  if (i == n) cout << " [OK]" << endl;
        
  double elapsed = (double)(cend - cstart) / CLOCKS_PER_SEC;
  cout << fixed << setprecision(PRECISION) << "  Time: " << elapsed << " s" << endl;
  cout << endl;
}  



// ---------------------------------------------------------------------------------
// Main function: test some input examples 
// (variants of input04 only tested if MERGESORT or RANDOMIZEDQUICKSORT are  defined
// For the last 8 cases, data handled as strings (to be sorted in lexicographic order)
// ---------------------------------------------------------------------------------
int main() {

  cout << "\n------------------ sorting integers ----------\n";

#ifdef SMALL
  testSort<int>("input01.txt", "output01.txt");  // sorted
  testSort<int>("r_input01.txt", "output01.txt"); // sorted in reverse order
  testSort<int>("s_input01.txt", "output01.txt"); // not sorted 
  testSort<int>("s_input01B.txt", "output01.txt"); // another not sorted
#endif

#ifdef MEDIUM
  testSort<int>("input02.txt", "output02.txt");
  testSort<int>("r_input02.txt", "output02.txt");
  testSort<int>("s_input02.txt", "output02.txt");
  testSort<int>("s_input02B.txt", "output02.txt");
#endif

#ifdef LARGE 
  testSort<int>("input03.txt", "output03.txt");
  testSort<int>("r_input03.txt", "output03.txt");
  testSort<int>("s_input03.txt", "output03.txt");
  testSort<int>("s_input03B.txt", "output03.txt");
#endif
  
#if defined(MERGESORT) || defined(RANDOMIZEDQUICKSORT) || defined(STL_SORT)
#ifdef HUGE
  testSort<int>("input04.txt", "output04.txt");
  testSort<int>("r_input04.txt", "output04.txt");
  testSort<int>("s_input04.txt", "output04.txt");
  testSort<int>("s_input04B.txt", "output04.txt");
#endif
#endif

  cout << "\n--------------- sorting strings (length <= 7)  ----------\n";
  
#ifdef MEDIUM
  testSort<string>("input02.txt", "str_output02.txt");  //  (integers in ascending order)
  testSort<string>("r_input02.txt", "str_output02.txt"); // (integers in descending order)
  testSort<string>("s_input02.txt", "str_output02.txt"); // not sorted
  testSort<string>("s_input02B.txt", "str_output02.txt"); // not sorted
#endif

#ifdef LARGE 
  testSort<string>("input03.txt", "str_output03.txt");  // (integers in ascending order)
  testSort<string>("r_input03.txt", "str_output03.txt"); // (integers in descending order)
  testSort<string>("s_input03.txt", "str_output03.txt"); // not sorted
  testSort<string>("s_input03B.txt", "str_output03.txt"); //not sorted 
#endif

#if defined(MERGESORT) || defined(RANDOMIZEDQUICKSORT)  || defined(STL_SORT)
#ifdef HUGE
  testSort<string>("input04.txt", "str_output04.txt");
  testSort<string>("r_input04.txt", "str_output04.txt");
  testSort<string>("s_input04.txt", "str_output04.txt");
  testSort<string>("s_input04B.txt", "str_output04.txt");
#endif
#endif
  return 0;
}
