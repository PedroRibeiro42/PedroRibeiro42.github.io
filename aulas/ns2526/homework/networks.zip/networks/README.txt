NetScience 25/26 Homework

8 directed networks (weighted adjacency lists)

- 2 word-adjacency networks taken out from books
  . english.txt
  . french.txt
- 2 transcriptional gene regulation networks
  . ecoli.txt (Escheria coli)
  . yeast.txt (Saccharomyces cerevisiae)
- 2 networks of human friendships
  . residence.txt (university residence hall)
  . highschool.txt (high school students)
- 2 networks of digital fractional multipliers electronic circuits
  . circuit1.txt
  . circuit2.txt

Sources for the networks:
https://www.weizmann.ac.il/mcb/UriAlon/download/collection-complex-networks
http://konect.cc/
